from django.apps import AppConfig


class Student2Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Student2'
